import javax.swing.JOptionPane;
import java.util.*;
import java.util.regex.Pattern;
import java.nio.file.*;
import java.io.IOException;

public class POE_PART_ONE1 {

    public static void main(String[] args) {
        RegisterApp.Prompting_user();
    }
}

class RegisterApp {

    static void Prompting_user() {
        Register1 app = new Register1();

        String first = JOptionPane.showInputDialog(null,
                "Enter first name:", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (first == null) return;

        String last = JOptionPane.showInputDialog(null,
                "Enter last name:", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (last == null) return;

        String user = JOptionPane.showInputDialog(null,
                "Create username (must contain '_' and be <= 5 chars):", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (user == null) return;

        String pass = JOptionPane.showInputDialog(null,
                "Create password (>=8 chars, include capital, number, lower-case):", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (pass == null) return;

        String cell = JOptionPane.showInputDialog(null,
                "Enter cell number with international code (e.g., +27XXXXXXXXX):", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (cell == null) return;

        String regMsg = app.registerUser(first.trim(), last.trim(), user.trim(), pass.trim(), cell.trim());
        JOptionPane.showMessageDialog(null, regMsg, "Registration Results", JOptionPane.INFORMATION_MESSAGE);

        if (app.username != null) {
            String lu = JOptionPane.showInputDialog(null,
                    "Login - Enter username:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (lu == null) return;

            String lp = JOptionPane.showInputDialog(null,
                    "Login - Enter password:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (lp == null) return;

            String loginMsg = app.returnLoginStatus(lu.trim(), lp.trim());
            JOptionPane.showMessageDialog(null, loginMsg, "Login Result", JOptionPane.INFORMATION_MESSAGE);

            if (loginMsg.startsWith("Welcome")) {
                new QuickChat(app.firstName, app.lastName).run();
            }
        } else {
            JOptionPane.showMessageDialog(null,
                    "Registration failed — please run the program again and correct the inputs.",
                    "Registration Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
}

class Register1 {
    String firstName;
    String lastName;
    String username;
    String password;
    String cellPhone;

    boolean checkUserName(String user) {
        if (user == null) return false;
        return user.contains("_") && user.length() <= 5;
    }

    boolean checkPasswordComplexity(String pass) {
        if (pass == null) return false;
        boolean longEnough = pass.length() >= 8;
        boolean hasCapital = Pattern.compile("[A-Z]").matcher(pass).find();
        boolean hasLower   = Pattern.compile("[a-z]").matcher(pass).find();
        boolean hasNumber  = Pattern.compile("[0-9]").matcher(pass).find();
        return longEnough && hasCapital && hasLower && hasNumber;
    }

    boolean checkCellPhoneNumber(String cell) {
        if (cell == null) return false;
        return Pattern.matches("^(\\+27|0)[6-8]\\d{8}$", cell);
    }

    String registerUser(String firstName, String lastName,
                        String username, String password, String cellPhone) {
        StringBuilder out = new StringBuilder();

        if (checkUserName(username)) out.append("Username successfully captured.\n");
        else out.append("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n");

        if (checkPasswordComplexity(password)) out.append("Password successfully captured.\n");
        else out.append("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");

        if (checkCellPhoneNumber(cellPhone)) out.append("Cell phone number successfully captured.\n");
        else out.append("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.\n");

        if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(cellPhone)) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.cellPhone = cellPhone;
        }
        return out.toString().trim();
    }

    String returnLoginStatus(String enteredUser, String enteredPass) {
        boolean ok = (this.username != null && this.password != null)
                && this.username.equals(enteredUser)
                && this.password.equals(enteredPass);

        if (ok) return "Welcome " + this.firstName + ", " + this.lastName + " it is great to see you again.";
        return "Username or password incorrect, please try again.";
    }
}

class QuickChat {

    static Object instance() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public final String userFirst;
    public final String userLast;
    public final List<Message> sentMessages = new ArrayList<>();
    public int totalSent = 0;

    QuickChat(String first, String last) {
        this.userFirst = first;
        this.userLast = last;
        MessageManager.loadSampleData(); // Load the 5 test messages on startup
    }

    void run() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.", "QuickChat", JOptionPane.INFORMATION_MESSAGE);

        while (true) {
            String choice = JOptionPane.showInputDialog(null, """
                                                              Choose an option:
                                                              1) Send Messages
                                                              2) View Sent Messages
                                                              3) Advanced Features (Report, Search, Delete)
                                                              4) Quit""",
                    "QuickChat Menu", JOptionPane.QUESTION_MESSAGE);
            if (choice == null) return;

            switch (choice.trim()) {
                case "1" -> handleSendMessages();
                case "2" -> MessageManager.displaySentMessagesDialog();
                case "3" -> showAdvancedMenu();
                case "4" -> {
                    MessageManager.showSummary();
                    JOptionPane.showMessageDialog(null, "Goodbye " + userFirst + " " + userLast + ".");
                    return;
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please select 1–4.");
            }
        }
    }

    private void showAdvancedMenu() {
        while (true) {
            String opt = JOptionPane.showInputDialog(null, """
                                                           Advanced Features:
                                                           1) Display Sender & Recipient (Sent)
                                                           2) Show Longest Message
                                                           3) Search by Message ID
                                                           4) Search by Recipient
                                                           5) Delete Message by Hash
                                                           6) Full Report (Sent Messages)
                                                           0) Back to Main Menu""",
                    "Advanced Features", JOptionPane.QUESTION_MESSAGE);

            if (opt == null || opt.trim().equals("0")) break;

            switch (opt.trim()) {
                case "1" -> MessageManager.displaySendersAndRecipients();
                case "2" -> MessageManager.showLongestMessage();
                case "3" -> MessageManager.searchByMessageIdInteractive();
                case "4" -> MessageManager.searchByRecipientInteractive();
                case "5" -> MessageManager.deleteByHashInteractive();
                case "6" -> MessageManager.displayReport();
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    public void handleSendMessages() {
        String countStr = JOptionPane.showInputDialog(null,
                "How many messages would you like to enter?", "Send Messages", JOptionPane.QUESTION_MESSAGE);
        if (countStr == null) return;

        int n;
        try {
            n = Integer.parseInt(countStr.trim());
            if (n <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a positive whole number.");
            return;
        }

        for (int i = 0; i < n; i++) {
            String recipient = JOptionPane.showInputDialog(null,
                    "Enter recipient cell (+27XXXXXXXXX or 0[6-8]XXXXXXXX):", "Message " + (i + 1), JOptionPane.QUESTION_MESSAGE);
            if (recipient == null) return;

            if (!Validator.checkRecipientCell(recipient.trim())) {
                JOptionPane.showMessageDialog(null, "Invalid cell number format.");
                i--;
                continue;
            }

            String content = JOptionPane.showInputDialog(null,
                    "Enter message (max 250 characters):", "Message " + (i + 1), JOptionPane.QUESTION_MESSAGE);
            if (content == null) return;

            if (content.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message too long by " + (content.length() - 250) + " characters.");
                i--;
                continue;
            }

            String messageId = Generator.generateMessageID();
            String messageHash = Generator.createMessageHash(messageId, content, MessageManager.getNextIndex());

            JOptionPane.showMessageDialog(null, "Message ID: " + messageId + "\nHash: " + messageHash);

            Object[] options = {"Send Message", "Disregard Message", "Store Message"};
            int opt = JOptionPane.showOptionDialog(null,
                    "Message ready. Choose action:", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            Message m = new Message(messageId, recipient.trim(), content.trim(), messageHash);

            switch (opt) {
                case 0 -> {
                    MessageManager.addMessage(recipient.trim(), content.trim(), "Sent", messageId, messageHash);
                    sentMessages.add(m);
                    totalSent++;
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> JOptionPane.showMessageDialog(null, "Message disregarded.");
                case 2 -> {
                    try {
                        Storage.storeMessageJSON(m);
                        MessageManager.addMessage(recipient.trim(), content.trim(), "Stored", messageId, messageHash);
                        JOptionPane.showMessageDialog(null, "Message stored to JSON.");
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Failed to store: " + ex.getMessage());
                    }
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalSent);
    }
}

// =======================================
// MESSAGE MANAGER – All POE Part 3 Features
// =======================================
class MessageManager {
    private static final int MAX_MESSAGES = 20;
    private static final String SENDER_NUMBER = "0838884567";

    private static final String[] allRecipients = new String[MAX_MESSAGES];
    private static final String[] allMessages   = new String[MAX_MESSAGES];
    private static final String[] allFlags      = new String[MAX_MESSAGES];
    private static final String[] messageIDs    = new String[MAX_MESSAGES];
    private static final String[] messageHashes = new String[MAX_MESSAGES];

    private static int totalCount = 0;

    static void loadSampleData() {
        if (totalCount > 0) return;
        addMessage("+27834557896", "Did you get the cake?", "Sent", "MSG001", "12345");
        addMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored", "MSG002", "67890");
        addMessage("+27834484567", "Yohoooo, I am at your gate.", "Disregard", "MSG003", "11223");
        addMessage("0838884567", "It is dinner time!", "Sent", "MSG004", "44556");
        addMessage("+27838884567", "Ok, I am leaving without you.", "Stored", "MSG005", "77889");
    }

    static void addMessage(String recipient, String text, String flag, String id, String hash) {
        if (totalCount >= MAX_MESSAGES) return;
        allRecipients[totalCount] = recipient;
        allMessages[totalCount]   = text;
        allFlags[totalCount]      = flag;
        messageIDs[totalCount]    = id;
        messageHashes[totalCount] = hash;
        totalCount++;
    }

    static int getNextIndex() {
        return totalCount;
    }

    static void displaySendersAndRecipients() {
        StringBuilder sb = new StringBuilder("Sender -> Recipient (Sent Messages):\n\n");
        for (int i = 0; i < totalCount; i++) {
            if ("Sent".equalsIgnoreCase(allFlags[i])) {
                sb.append(SENDER_NUMBER).append(" -> ").append(allRecipients[i]).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    static void showLongestMessage() {
        String longest = "";
        for (int i = 0; i < totalCount; i++) {
            if (allMessages[i] != null && allMessages[i].length() > longest.length()) {
                longest = allMessages[i];
            }
        }
        JOptionPane.showMessageDialog(null, longest.isEmpty() ? "No messages." : "Longest message:\n" + longest);
    }

    static void searchByMessageIdInteractive() {
        String id = JOptionPane.showInputDialog("Enter Message ID:");
        if (id == null) return;
        for (int i = 0; i < totalCount; i++) {
            if (id.equals(messageIDs[i])) {
                JOptionPane.showMessageDialog(null, "Found:\nRecipient: " + allRecipients[i] + "\nMessage: " + allMessages[i]);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    static void searchByRecipientInteractive() {
        String rec = JOptionPane.showInputDialog("Enter recipient number:");
        if (rec == null) return;
        StringBuilder sb = new StringBuilder("Messages for " + rec + " (Sent/Stored):\n\n");
        boolean found = false;
        for (int i = 0; i < totalCount; i++) {
            if (rec.equals(allRecipients[i]) && ("Sent".equalsIgnoreCase(allFlags[i]) || "Stored".equalsIgnoreCase(allFlags[i]))) {
                sb.append(allMessages[i]).append("\n\n");
                found = true;
            }
        }
        JOptionPane.showMessageDialog(null, found ? sb.toString() : "No messages found.");
    }

    static void deleteByHashInteractive() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        if (hash == null) return;
        for (int i = 0; i < totalCount; i++) {
            if (hash.equals(messageHashes[i])) {
                allMessages[i] = null;
                allFlags[i] = "Deleted";
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Hash not found.");
    }

    static void displayReport() {
        StringBuilder sb = new StringBuilder("=== SENT MESSAGES REPORT ===\n\n");
        sb.append(String.format("%-15s %-15s %s%n", "Hash", "Recipient", "Message"));
        sb.append("-------------------------------------------------------------\n");
        for (int i = 0; i < totalCount; i++) {
            if ("Sent".equalsIgnoreCase(allFlags[i])) {
                sb.append(String.format("%-15s %-15s %s%n", messageHashes[i], allRecipients[i], allMessages[i]));
            }
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Full Report", JOptionPane.INFORMATION_MESSAGE);
    }

    static void displaySentMessagesDialog() {
        StringBuilder sb = new StringBuilder("Recently Sent Messages:\n\n");
        boolean has = false;
        for (int i = 0; i < totalCount; i++) {
            if ("Sent".equalsIgnoreCase(allFlags[i])) {
                sb.append("To: ").append(allRecipients[i]).append("\n")
                  .append(allMessages[i]).append("\n\n");
                has = true;
            }
        }
        JOptionPane.showMessageDialog(null, has ? sb.toString() : "No sent messages.");
    }

    static void showSummary() {
        displaySentMessagesDialog();
        JOptionPane.showMessageDialog(null, QuickChat.instance() + "Total sent during session: ");
    }
    // Helper to access current QuickChat instance if needed
}

class Validator {
    static boolean checkRecipientCell(String cell) {
        if (cell == null) return false;
        return Pattern.matches("^(\\+27|0)[6-8]\\d{8}$", cell);
    }
}

class Generator {
    public static final Random RAND = new Random();

    static String generateMessageID() {
        StringBuilder sb = new StringBuilder("MSG");
        for (int i = 0; i < 7; i++) sb.append(RAND.nextInt(10));
        return sb.toString().substring(0, 10);
    }

    static String createMessageHash(String messageId, String message, int index) {
        String firstTwo = messageId.length() >= 2 ? messageId.substring(0, 2) : "00";
        String[] words = message.trim().split("\\s+");
        String first = words.length > 0 ? words[0].toUpperCase() : "";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        return firstTwo + ":" + index + ":" + first + last;
    }
}

class Message {
    final String messageId, recipient, content, messageHash;
    Message(String id, String rec, String cont, String hash) {
        this.messageId = id; this.recipient = rec; this.content = cont; this.messageHash = hash;
    }
}

class Storage {
    public static final Path FILE = Paths.get("messages.json");

    static void storeMessageJSON(Message m) throws IOException {
        String jsonLine = "  {\"messageId\":\"" + escape(m.messageId) + "\"," +
                          " \"recipient\":\"" + escape(m.recipient) + "\"," +
                          " \"content\":\"" + escape(m.content) + "\"," +
                          " \"messageHash\":\"" + escape(m.messageHash) + "\"}";

        if (!Files.exists(FILE)) {
            Files.writeString(FILE, "[\n" + jsonLine + "\n]");
        } else {
            String content = Files.readString(FILE).trim();
            if (content.endsWith("]")) {
                String newContent = content.substring(0, content.length() - 1);
                if (!content.endsWith("[")) newContent += ",\n";
                Files.writeString(FILE, newContent + jsonLine + "\n]");
            }
        }
    }

    private static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
      