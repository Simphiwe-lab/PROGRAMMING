/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_part_one1;

import java.util.regex.Pattern;

/**
 *
 * @author RC_Student_lab
 */


class Register1 {

    // User info fields with default (package-private) visibility
    String firstName;
    String lastName;
    String username;
    String password;
    String cellPhone;
   

    // Check username contains underscore and is max 5 chars
    boolean checkUserName(String user) {
        if (user == null) return false;
        boolean hasUnderscore = user.contains("_");
        boolean maxFive = user.length() <= 5;
        return hasUnderscore && maxFive;
    }

    // Check password complexity: min 8 chars, uppercase, lowercase, digit
    boolean checkPasswordComplexity(String pass) {
        if (pass == null) return false;
        boolean longEnough = pass.length() >= 8;
        boolean hasCapital = Pattern.compile("[A-Z]").matcher(pass).find();
        boolean hasLower = Pattern.compile("[a-z]").matcher(pass).find();
        boolean hasNumber = Pattern.compile("[0-9]").matcher(pass).find();
        return longEnough && hasCapital && hasLower && hasNumber;
    }

    // Check SA cellphone number: starts with +27 or 0, then 6-8, then 8 digits
    boolean checkCellPhoneNumber(String cell) {
        if (cell == null) return false;
        return Pattern.matches("^(\\+27|0)[6-8]\\d{8}$", cell);
    }

    // Register user and return status messages
    String registerUser(String firstName, String lastName,
                        String username, String password, String cellPhone) {
        StringBuilder out = new StringBuilder();

        if (checkUserName(username)) {
            out.append("Username successfully captured.\n");
        } else {
            out.append("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n");
        }

        if (checkPasswordComplexity(password)) {
            out.append("Password successfully captured.\n");
        } else {
            out.append("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
        }

        if (checkCellPhoneNumber(cellPhone)) {
            out.append("Cell number successfully added.\n");
        } else {
            out.append("Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.\n");
        }

        if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(cellPhone)) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.cellPhone = cellPhone;
        }

        return out.toString().trim();
    }

    // Return login status message
    String returnLoginStatus(String enteredUser, String enteredPass) {
        boolean ok = (this.username != null && this.password != null)
                && this.username.equals(enteredUser)
                && this.password.equals(enteredPass);

        if (ok) {
            return "Welcome " + this.firstName + ", " + this.lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
        
    }
    }